# NitroDiscordBot
An discord bot which generates fake discord nitro messages proofs ;-;

Sends a picture of "nitro proof" after use of the commands, Can be used in fake nitro servers ect. Commands are (prefix)boost (username) (text) and classic (username) (text)

Scrapes profile pictures from servers that the bot is in.
Ex:
>boost kakashi LEGIT TYSM
